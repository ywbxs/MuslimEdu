<?php

namespace App\Http\Controllers;

use App\Models\Curriculum;
use App\Models\CurriculumCompetency;
use App\Models\CurriculumVersion;
use App\Models\Enrollment;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * §4.6 Curriculum versioning. A curriculum can be revised over time —
 * new credit requirements, new prerequisites, new competencies — without
 * rewriting what a currently-enrolled student is held to. Each revision is
 * its own CurriculumVersion row; `enrollment.curriculum_version_id` (see
 * the companion migration) pins a student to whichever version was active
 * when they enrolled, so editing the curriculum later never silently
 * changes what an already-enrolled student is on the hook for.
 *
 * Every query is scoped through the parent Curriculum's school_id (never
 * trusted from the request payload directly), same pattern as
 * AttendanceConfigController / PermissionController.
 *
 * NOTE on scope: prerequisites/co-requisites are NOT handled here. They
 * already exist as a subject-level feature — `Subject::prerequisites()` /
 * `corequisites()`, backed by the `subject_prerequisites` table and wired
 * into AcademicCatalogController's subject create/update endpoints. This
 * controller only adds what didn't already exist: versioned credit
 * requirements and competencies.
 */
class CurriculumVersionController extends Controller
{
    protected const ADMIN_ROLES = [1, 2];

    protected function admin(Request $request)
    {
        $actor = $request->user();

        if (! $actor || ! in_array((int) $actor->role_id, self::ADMIN_ROLES, true)) {
            return response()->json(['message' => 'Administrator permission required.'], 403);
        }

        return $actor;
    }

    /** Resolves a curriculum_id to a Curriculum scoped to the actor's school, or null. */
    protected function curriculumFor($actor, $curriculumId): ?Curriculum
    {
        return Curriculum::where('id', $curriculumId)->where('school_id', $actor->school_id)->first();
    }

    /** Resolves a curriculum_version_id to a version scoped to the actor's school via its curriculum. */
    protected function versionFor($actor, $versionId): ?CurriculumVersion
    {
        return CurriculumVersion::where('id', $versionId)->where('school_id', $actor->school_id)->first();
    }

    // ===============================================================
    // Versions
    // ===============================================================

    /** POST /api/admin_curriculum_version_list */
    public function versionList(Request $request)
    {
        $actor = $this->admin($request);
        if ($actor instanceof JsonResponse) {
            return $actor;
        }

        $data = $request->validate(['curriculum_id' => 'required|integer']);

        $curriculum = $this->curriculumFor($actor, $data['curriculum_id']);
        if (! $curriculum) {
            return response()->json(['message' => 'Curriculum not found.'], 404);
        }

        return response()->json([
            'versions' => $curriculum->versions()->orderByDesc('effective_date')->get(),
        ], 200);
    }

    /** POST /api/admin_curriculum_version_save */
    public function versionSave(Request $request)
    {
        $actor = $this->admin($request);
        if ($actor instanceof JsonResponse) {
            return $actor;
        }

        $data = $request->validate([
            'id'                   => 'nullable|integer',
            'curriculum_id'        => 'required_without:id|nullable|integer',
            'version_label'        => 'required|string|max:60',
            'effective_date'       => 'required|date',
            'end_date'             => 'nullable|date|after_or_equal:effective_date',
            'status'               => 'nullable|in:draft,active,retired',
            'credit_requirements'  => 'nullable|array',
            'notes'                => 'nullable|string|max:2000',
        ]);

        $version = null;
        $curriculum = null;

        if (! empty($data['id'])) {
            $version = $this->versionFor($actor, $data['id']);
            if (! $version) {
                return response()->json(['message' => 'Curriculum version not found.'], 404);
            }
            $curriculum = $version->curriculum;
        } else {
            $curriculum = $this->curriculumFor($actor, $data['curriculum_id']);
            if (! $curriculum) {
                return response()->json(['message' => 'Curriculum not found.'], 404);
            }

            $duplicateLabel = CurriculumVersion::where('curriculum_id', $curriculum->id)
                ->where('version_label', $data['version_label'])
                ->exists();
            if ($duplicateLabel) {
                return response()->json([
                    'message' => 'A version with this label already exists for this curriculum.',
                ], 422);
            }
        }

        $payload = [
            'version_label'       => $data['version_label'],
            'effective_date'      => $data['effective_date'],
            'end_date'            => $data['end_date'] ?? null,
            'credit_requirements' => $data['credit_requirements'] ?? null,
            'notes'               => $data['notes'] ?? null,
            'updated_by'          => $actor->id,
        ];

        $wantsActive = ($data['status'] ?? null) === 'active';

        DB::transaction(function () use (&$version, $curriculum, $payload, $data, $wantsActive, $actor) {
            if ($wantsActive) {
                // Only one active version per curriculum. Retiring the old
                // active version here (rather than deleting it) keeps every
                // already-pinned enrollment's requirements/competencies
                // readable — this never touches enrollment rows.
                CurriculumVersion::where('curriculum_id', $curriculum->id)
                    ->where('status', 'active')
                    ->when($version, fn ($q) => $q->where('id', '!=', $version->id))
                    ->update(['status' => 'retired', 'updated_by' => $actor->id]);
            }

            $payload['status'] = $data['status'] ?? ($version->status ?? 'draft');

            if ($version) {
                $version->fill($payload)->save();
            } else {
                $version = CurriculumVersion::create(array_merge($payload, [
                    'school_id'      => $curriculum->school_id,
                    'curriculum_id'  => $curriculum->id,
                    'created_by'     => $actor->id,
                ]));
            }
        });

        return response()->json([
            'message' => 'Curriculum version saved.',
            'version' => $version->fresh(),
        ], 201);
    }

    /** POST /api/admin_curriculum_version_delete */
    public function versionDelete(Request $request)
    {
        $actor = $this->admin($request);
        if ($actor instanceof JsonResponse) {
            return $actor;
        }

        $data = $request->validate(['id' => 'required|integer']);

        $version = $this->versionFor($actor, $data['id']);
        if (! $version) {
            return response()->json(['message' => 'Curriculum version not found.'], 404);
        }

        if (Enrollment::where('curriculum_version_id', $version->id)->exists()) {
            return response()->json([
                'message' => 'Students are pinned to this version. Retire it instead of deleting.',
            ], 422);
        }

        // No enrollments reference it, so its competencies are only draft
        // configuration - safe to cascade.
        $version->competencies()->delete();
        $version->delete();

        return response()->json(['message' => 'Curriculum version removed.'], 200);
    }

    // ===============================================================
    // Competencies
    // ===============================================================

    /** POST /api/admin_curriculum_competency_list */
    public function competencyList(Request $request)
    {
        $actor = $this->admin($request);
        if ($actor instanceof JsonResponse) {
            return $actor;
        }

        $data = $request->validate(['curriculum_version_id' => 'required|integer']);

        $version = $this->versionFor($actor, $data['curriculum_version_id']);
        if (! $version) {
            return response()->json(['message' => 'Curriculum version not found.'], 404);
        }

        return response()->json(['competencies' => $version->competencies], 200);
    }

    /** POST /api/admin_curriculum_competency_save */
    public function competencySave(Request $request)
    {
        $actor = $this->admin($request);
        if ($actor instanceof JsonResponse) {
            return $actor;
        }

        $data = $request->validate([
            'id'                     => 'nullable|integer',
            'curriculum_version_id'  => 'required_without:id|nullable|integer',
            'code'                   => 'required_without:id|nullable|string|max:40',
            'title'                  => 'required|string|max:150',
            'description'            => 'nullable|string|max:2000',
            'category'               => 'nullable|in:academic,islamic_studies,arabic,other',
            'sort_order'             => 'nullable|integer|min:0',
        ]);

        $competency = null;
        $version = null;

        if (! empty($data['id'])) {
            $competency = CurriculumCompetency::whereHas(
                'version',
                fn ($q) => $q->where('school_id', $actor->school_id)
            )->where('id', $data['id'])->first();

            if (! $competency) {
                return response()->json(['message' => 'Competency not found.'], 404);
            }
            $version = $competency->version;
            unset($data['code']); // code is immutable after creation, same reasoning as attendance status codes
        } else {
            $version = $this->versionFor($actor, $data['curriculum_version_id']);
            if (! $version) {
                return response()->json(['message' => 'Curriculum version not found.'], 404);
            }

            $duplicate = CurriculumCompetency::where('curriculum_version_id', $version->id)
                ->where('code', $data['code'])
                ->exists();
            if ($duplicate) {
                return response()->json(['message' => 'A competency with this code already exists on this version.'], 422);
            }
        }

        $payload = [
            'title'       => $data['title'],
            'description' => $data['description'] ?? null,
            'category'    => $data['category'] ?? ($competency->category ?? 'academic'),
            'sort_order'  => $data['sort_order'] ?? ($competency->sort_order ?? 0),
        ];

        if ($competency) {
            $competency->fill($payload)->save();
        } else {
            $competency = CurriculumCompetency::create(array_merge($payload, [
                'curriculum_version_id' => $version->id,
                'code'                  => $data['code'],
            ]));
        }

        return response()->json([
            'message'    => 'Competency saved.',
            'competency' => $competency->fresh(),
        ], 201);
    }

    /** POST /api/admin_curriculum_competency_delete */
    public function competencyDelete(Request $request)
    {
        $actor = $this->admin($request);
        if ($actor instanceof JsonResponse) {
            return $actor;
        }

        $data = $request->validate(['id' => 'required|integer']);

        $competency = CurriculumCompetency::whereHas(
            'version',
            fn ($q) => $q->where('school_id', $actor->school_id)
        )->where('id', $data['id'])->first();

        if (! $competency) {
            return response()->json(['message' => 'Competency not found.'], 404);
        }

        $competency->delete();

        return response()->json(['message' => 'Competency removed.'], 200);
    }
}
