<?php

namespace App\Http\Controllers;

use App\Models\CapabilityFlag;
use App\Models\PermissionGrant;
use App\Services\AcademicAuthorizationService;
use App\Support\PermissionCatalog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * §4.20 Real permissions CRUD. Admins grant/revoke per-role capabilities
 * (optionally scoped to a campus or department) and toggle optional
 * modules on/off, all data-driven via permission_grants / capability_flags
 * rather than hardcoded role checks.
 *
 * This controller was missing from the repo entirely — routes/api.php
 * already registered 6 routes pointing at it (admin_permission_catalog,
 * admin_permission_list, admin_permission_save, admin_permission_delete,
 * admin_capability_flag_list, admin_capability_flag_save), which would
 * 500 with a class-not-found error until this file existed. The model
 * (PermissionGrant), migration, and PermissionCatalog support class were
 * already present and are used as-is here.
 *
 * IMPORTANT: PermissionGrant::roleHas() / CapabilityFlag::isEnabled() are
 * primitives only — nothing outside this controller enforces a grant yet.
 * Writing this controller does not retrofit existing endpoints.
 *
 * Every query is scoped to the authenticated admin's own school_id, never
 * from the request payload, so an id can't be used to reach across
 * schools (same pattern as AttendanceConfigController).
 */
class PermissionController extends Controller
{
    protected const ADMIN_ROLES = [1, 2];

    // Role tiers this app actually has (matches users.role_id everywhere
    // else in the codebase). Kept here rather than a `roles` table per the
    // migration's own comment.
    protected const ROLE_LABELS = [
        1 => 'Superadmin',
        2 => 'Admin',
        3 => 'Teacher',
        7 => 'Student',
    ];

    protected function admin(Request $request)
    {
        $actor = $request->user();

        if (! $actor || ! in_array((int) $actor->role_id, self::ADMIN_ROLES, true)) {
            return response()->json(['message' => 'Administrator permission required.'], 403);
        }

        return $actor;
    }

    // ===============================================================
    // Catalog — the fixed, code-defined list of keys/roles the UI
    // renders as dropdowns. Not itself editable data.
    // ===============================================================

    /** POST /api/admin_permission_catalog */
    public function catalog(Request $request)
    {
        $actor = $this->admin($request);
        if ($actor instanceof JsonResponse) {
            return $actor;
        }

        return response()->json([
            'permission_keys' => PermissionCatalog::permissionKeys(),
            'module_keys'     => PermissionCatalog::moduleKeys(),
            'roles'           => self::ROLE_LABELS,
            'scope_types'     => ['campus', 'department'],
        ], 200);
    }

    // ===============================================================
    // Permission grants
    // ===============================================================

    /** POST /api/admin_permission_list */
    public function list(Request $request)
    {
        $actor = $this->admin($request);
        if ($actor instanceof JsonResponse) {
            return $actor;
        }

        $data = $request->validate([
            'role_id'        => 'nullable|integer',
            'permission_key' => 'nullable|string',
        ]);

        $query = PermissionGrant::where('school_id', $actor->school_id);

        if (! empty($data['role_id'])) {
            $query->where('role_id', $data['role_id']);
        }
        if (! empty($data['permission_key'])) {
            $query->where('permission_key', $data['permission_key']);
        }

        return response()->json([
            'grants' => $query->orderBy('permission_key')->orderBy('role_id')->get(),
        ], 200);
    }

    /** POST /api/admin_permission_save */
    public function save(Request $request)
    {
        $actor = $this->admin($request);
        if ($actor instanceof JsonResponse) {
            return $actor;
        }

        $data = $request->validate([
            'id'             => 'nullable|integer',
            'role_id'        => 'required|integer|in:1,2,3,7',
            'permission_key' => 'required|string|max:100',
            'scope_type'     => 'nullable|string|in:campus,department',
            'scope_id'       => 'nullable|integer|required_with:scope_type',
            'can_access'     => 'required|boolean',
            'can_approve'    => 'nullable|boolean',
            'can_override'   => 'nullable|boolean',
            'is_active'      => 'nullable|boolean',
        ]);

        if (! PermissionCatalog::isValidPermissionKey($data['permission_key'])) {
            return response()->json(['message' => 'Unknown permission_key.'], 422);
        }

        $grant = null;
        if (! empty($data['id'])) {
            $grant = PermissionGrant::where('id', $data['id'])
                ->where('school_id', $actor->school_id)
                ->first();

            if (! $grant) {
                return response()->json(['message' => 'Permission grant not found.'], 404);
            }
        }

        $payload = [
            'school_id'      => $actor->school_id,
            'role_id'        => $data['role_id'],
            'permission_key' => $data['permission_key'],
            'scope_type'     => $data['scope_type'] ?? null,
            'scope_id'       => $data['scope_type'] ?? null ? ($data['scope_id'] ?? null) : null,
            'can_access'     => $data['can_access'],
            'can_approve'    => $data['can_approve'] ?? false,
            'can_override'   => $data['can_override'] ?? false,
            'is_active'      => $data['is_active'] ?? true,
            'updated_by'     => $actor->id,
        ];

        // Same school/role/key/scope combination can't have two grants —
        // the unique index would 500 on a raw duplicate insert; catch it
        // here with a clean 422 instead.
        $duplicate = PermissionGrant::where('school_id', $actor->school_id)
            ->where('role_id', $payload['role_id'])
            ->where('permission_key', $payload['permission_key'])
            ->where('scope_type', $payload['scope_type'])
            ->where('scope_id', $payload['scope_id'])
            ->when($grant, fn ($q) => $q->where('id', '!=', $grant->id))
            ->exists();

        if ($duplicate) {
            return response()->json([
                'message' => 'A grant for this role, permission, and scope already exists.',
            ], 422);
        }

        if ($grant) {
            $grant->fill($payload)->save();
        } else {
            $payload['created_by'] = $actor->id;
            $grant = PermissionGrant::create($payload);
        }

        app(AcademicAuthorizationService::class)->audit(
            $request,
            'permission_grant.save',
            'allowed',
            'permission_grant',
            $grant->id,
            null,
            ['role_id' => $grant->role_id, 'permission_key' => $grant->permission_key]
        );

        return response()->json([
            'message' => 'Permission grant saved.',
            'grant'   => $grant->fresh(),
        ], 201);
    }

    /** POST /api/admin_permission_delete */
    public function delete(Request $request)
    {
        $actor = $this->admin($request);
        if ($actor instanceof JsonResponse) {
            return $actor;
        }

        $data = $request->validate(['id' => 'required|integer']);

        $grant = PermissionGrant::where('id', $data['id'])
            ->where('school_id', $actor->school_id)
            ->first();

        if (! $grant) {
            return response()->json(['message' => 'Permission grant not found.'], 404);
        }

        $grant->delete();

        app(AcademicAuthorizationService::class)->audit(
            $request,
            'permission_grant.delete',
            'allowed',
            'permission_grant',
            $data['id']
        );

        return response()->json(['message' => 'Permission grant removed.'], 200);
    }

    // ===============================================================
    // Capability flags (optional modules)
    // ===============================================================

    /** POST /api/admin_capability_flag_list */
    public function capabilityList(Request $request)
    {
        $actor = $this->admin($request);
        if ($actor instanceof JsonResponse) {
            return $actor;
        }

        $existing = CapabilityFlag::where('school_id', $actor->school_id)->get()->keyBy('module_key');

        // Always return one row per known module key, even if the school
        // has never touched it — the RN screen shouldn't have to know
        // which modules exist vs. which have been configured.
        $flags = collect(PermissionCatalog::moduleKeys())->map(function ($label, $key) use ($existing) {
            $flag = $existing->get($key);

            return [
                'id'          => $flag->id ?? null,
                'module_key'  => $key,
                'label'       => $label,
                'is_enabled'  => $flag->is_enabled ?? false,
                'config'      => $flag->config ?? null,
            ];
        })->values();

        return response()->json(['flags' => $flags], 200);
    }

    /** POST /api/admin_capability_flag_save */
    public function capabilitySave(Request $request)
    {
        $actor = $this->admin($request);
        if ($actor instanceof JsonResponse) {
            return $actor;
        }

        $data = $request->validate([
            'module_key' => 'required|string|max:60',
            'is_enabled' => 'required|boolean',
            'config'     => 'nullable|array',
        ]);

        if (! PermissionCatalog::isValidModuleKey($data['module_key'])) {
            return response()->json(['message' => 'Unknown module_key.'], 422);
        }

        $flag = CapabilityFlag::updateOrCreate(
            ['school_id' => $actor->school_id, 'module_key' => $data['module_key']],
            [
                'is_enabled' => $data['is_enabled'],
                'config'     => $data['config'] ?? null,
                'updated_by' => $actor->id,
            ]
        );

        app(AcademicAuthorizationService::class)->audit(
            $request,
            'capability_flag.save',
            'allowed',
            'capability_flag',
            $flag->id,
            null,
            ['module_key' => $flag->module_key, 'is_enabled' => $flag->is_enabled]
        );

        return response()->json([
            'message' => 'Capability flag saved.',
            'flag'    => $flag->fresh(),
        ], 201);
    }
}
