<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Curriculum extends Model
{
    protected $table = 'curricula';

    protected $fillable = [
        'school_id',
        'name',
        'code',
        'department_id',
        'effective_school_year_id',
        'description',
        'status',
    ];

    public function school()
    {
        return $this->belongsTo(School::class, 'school_id');
    }

    public function classes()
    {
        return $this->hasMany(Classes::class, 'curriculum_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class, 'department_id');
    }

    public function effectiveSchoolYear()
    {
        return $this->belongsTo(Session::class, 'effective_school_year_id');
    }

    public function versions()
    {
        return $this->hasMany(CurriculumVersion::class, 'curriculum_id');
    }

    /** The single version currently marked 'active', if any. */
    public function activeVersion()
    {
        return $this->hasOne(CurriculumVersion::class, 'curriculum_id')->where('status', 'active');
    }

    // Scopes

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }
}
