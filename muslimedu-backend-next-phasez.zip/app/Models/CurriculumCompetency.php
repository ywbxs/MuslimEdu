<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CurriculumCompetency extends Model
{
    protected $fillable = [
        'curriculum_version_id',
        'code',
        'title',
        'description',
        'category',
        'sort_order',
    ];

    public function version()
    {
        return $this->belongsTo(CurriculumVersion::class, 'curriculum_version_id');
    }
}
