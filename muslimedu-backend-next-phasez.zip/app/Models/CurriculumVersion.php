<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CurriculumVersion extends Model
{
    protected $fillable = [
        'school_id',
        'curriculum_id',
        'version_label',
        'effective_date',
        'end_date',
        'status',
        'credit_requirements',
        'notes',
        'created_by',
        'updated_by',
    ];

    protected $casts = [
        'credit_requirements' => 'array',
        'effective_date'      => 'date',
        'end_date'            => 'date',
    ];

    public function curriculum()
    {
        return $this->belongsTo(Curriculum::class, 'curriculum_id');
    }

    public function competencies()
    {
        return $this->hasMany(CurriculumCompetency::class, 'curriculum_version_id')->orderBy('sort_order');
    }

    public function enrollments()
    {
        return $this->hasMany(Enrollment::class, 'curriculum_version_id');
    }
}
