<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// §4.6 Curriculum versioning. A curriculum can change over time (new
// credit requirements, new competencies) without rewriting history for
// students already enrolled under an older version — each version is its
// own row with its own effective_date/status, and enrollment.
// curriculum_version_id (added in a companion migration) pins a student
// to the exact version they enrolled under.
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('curriculum_versions')) {
            return;
        }

        Schema::create('curriculum_versions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('school_id')->index();
            $table->unsignedBigInteger('curriculum_id')->index();

            // e.g. "2026-2027", "v2", "Rev. B" - admin-chosen, not auto-numbered,
            // since schools name curriculum revisions differently.
            $table->string('version_label', 60);

            $table->date('effective_date');
            $table->date('end_date')->nullable();

            // Only one version per curriculum may be 'active' at a time -
            // enforced in the controller, not the DB, so the transition
            // (activate new -> retire old) can run inside one transaction.
            $table->enum('status', ['draft', 'active', 'retired'])->default('draft');

            // Free-form structured credit rules, e.g.
            // {"total_credits": 120, "core_credits": 60, "elective_credits": 30,
            //  "islamic_studies_credits": 12, "arabic_credits": 12}
            // Kept as JSON rather than fixed columns - the spec's credit
            // categories vary by school and grade level.
            $table->json('credit_requirements')->nullable();

            $table->text('notes')->nullable();

            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();

            $table->unique(['curriculum_id', 'version_label'], 'curriculum_versions_curriculum_label_unique');
            $table->index(['curriculum_id', 'status'], 'curriculum_versions_curriculum_status_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('curriculum_versions');
    }
};
