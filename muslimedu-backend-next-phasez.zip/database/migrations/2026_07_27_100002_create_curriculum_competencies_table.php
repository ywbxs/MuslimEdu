<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// §4.6 competencies (including Islamic Studies / Arabic), scoped to one
// curriculum_version for the same reason as curriculum_requirements above.
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('curriculum_competencies')) {
            return;
        }

        Schema::create('curriculum_competencies', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('curriculum_version_id')->index();

            $table->string('code', 40);
            $table->string('title', 150);
            $table->text('description')->nullable();

            $table->enum('category', ['academic', 'islamic_studies', 'arabic', 'other'])->default('academic');

            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();

            $table->unique(['curriculum_version_id', 'code'], 'curriculum_competencies_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('curriculum_competencies');
    }
};
