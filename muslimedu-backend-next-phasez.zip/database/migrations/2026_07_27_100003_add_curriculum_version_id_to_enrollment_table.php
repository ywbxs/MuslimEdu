<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// §4.6 "pinning students to the version they enrolled under". `enrollment`
// is already the per-session record of a student's placement (class,
// section, department, session) — adding curriculum_version_id here means
// a student's curriculum requirements/competencies are read from whatever
// version was active when this row was created, and never silently change
// underneath them if the curriculum is revised later.
//
// Nullable: existing enrollment rows predate curriculum versioning and have
// no version to backfill from (the curriculum_versions table starts empty).
// Only new enrollments going forward get pinned.
return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasColumn('enrollment', 'curriculum_version_id')) {
            return;
        }

        Schema::table('enrollment', function (Blueprint $table) {
            $table->unsignedBigInteger('curriculum_version_id')->nullable()->after('session_id')->index();
        });
    }

    public function down(): void
    {
        Schema::table('enrollment', function (Blueprint $table) {
            if (Schema::hasColumn('enrollment', 'curriculum_version_id')) {
                $table->dropColumn('curriculum_version_id');
            }
        });
    }
};
