<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ApiController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\EnrollmentWorkflowController;
use App\Http\Controllers\AcademicSetupController;
use App\Http\Controllers\AcademicSetupPhase6Controller;
use App\Http\Controllers\AcademicCatalogController;
use App\Http\Controllers\AcademicStructureController;
use App\Http\Controllers\StudentIdentityController;
use App\Http\Controllers\AcademicCompletionController;
use App\Http\Controllers\AcademicGradeController;
use App\Http\Controllers\AcademicScheduleController;
use App\Http\Controllers\AcademicPolicyController;
use App\Http\Controllers\AcademicAnalyticsController;
use App\Http\Controllers\AcademicAuthorizationController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\AcademicCalendarController;
use App\Http\Controllers\AcademicCommunicationController;
use App\Http\Controllers\AcademicDocumentController;
use App\Http\Controllers\AcademicFacilitiesController;
use App\Http\Controllers\AcademicIntegrationController;
use App\Http\Controllers\AcademicLocaleController;
use App\Http\Controllers\AcademicPortalController;
use App\Http\Controllers\AcademicStudentLifecycleController;
use App\Http\Controllers\AttendanceConfigController;
use App\Http\Controllers\CurriculumVersionController;
use App\Http\Controllers\SubjectLoadingController;
use App\Http\Controllers\AcademicCompletionEngineController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/



Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/login', [ApiController::class, 'login']);

Route::group(['middleware' => ['auth:sanctum']], function () {
    Route::post('/me', [ApiController::class, 'me']);
    Route::post('/logout-all', [ApiController::class, 'logoutAll']);
    Route::post('/user_details', [ApiController::class, 'userDetails']);
    Route::post('/routine', [ApiController::class, 'routine']);
    Route::post('/attendance', [ApiController::class, 'attendanceReport']);
    Route::post('/subjects', [ApiController::class, 'subjects']);
    Route::post('/syllabus_list', [ApiController::class, 'syllabus_list']);
    Route::post('/teacher_list', [ApiController::class, 'teacher_list']);
    Route::post('/book_list', [ApiController::class, 'book_list']);
    Route::post('/book_issue_list', [ApiController::class, 'book_issue_list']);
    Route::post('/exam_list', [ApiController::class, 'exam_list']);
    Route::post('/marks', [ApiController::class, 'marks']);
    Route::post('/profile_update', [ApiController::class, 'profile_update']);
    Route::post('/fee_list', [ApiController::class, 'fee_list']);
    Route::post('/logout', [ApiController::class, 'logout']);
    Route::post('/account_delete', [ApiController::class, 'account_delete']);
    Route::post('/change_profile_photo', [ApiController::class, 'change_profile_photo']);

    // Orphan Management - child-facing
    Route::post('/orphan_profile', [ApiController::class, 'orphan_profile']);
    Route::post('/orphan_report_status', [ApiController::class, 'orphan_report_status']);
    Route::post('/orphan_report_submit', [ApiController::class, 'orphan_report_submit']);
    Route::post('/orphan_sponsorship', [ApiController::class, 'orphan_sponsorship']);

    // Orphan Management - admin-facing
    Route::post('/admin_children_list', [ApiController::class, 'admin_children_list']);
    Route::post('/admin_child_profile', [ApiController::class, 'admin_child_profile']);
    Route::post('/admin_child_orphan_profile_update', [ApiController::class, 'admin_child_orphan_profile_update']);
    Route::post('/admin_child_basic_profile_update', [ApiController::class, 'admin_child_basic_profile_update']);
    Route::post('/admin_orphan_report_list', [ApiController::class, 'admin_orphan_report_list']);
    Route::post('/admin_orphan_report_create', [ApiController::class, 'admin_orphan_report_create']);
    Route::post('/admin_orphan_report_delete', [ApiController::class, 'admin_orphan_report_delete']);
    Route::post('/admin_orphan_report_overview', [ApiController::class, 'admin_orphan_report_overview']);
    Route::post('/admin_sponsor_list', [ApiController::class, 'admin_sponsor_list']);
    Route::post('/admin_sponsor_store', [ApiController::class, 'admin_sponsor_store']);
    Route::post('/admin_sponsor_update', [ApiController::class, 'admin_sponsor_update']);
    Route::post('/admin_sponsor_delete', [ApiController::class, 'admin_sponsor_delete']);
    Route::post('/admin_sponsor_reset_password', [ApiController::class, 'admin_sponsor_reset_password']);
    Route::post('/admin_sponsorship_detail', [ApiController::class, 'admin_sponsorship_detail']);
    Route::post('/admin_sponsorship_assign', [ApiController::class, 'admin_sponsorship_assign']);
    Route::post('/admin_sponsorship_payment_store', [ApiController::class, 'admin_sponsorship_payment_store']);
    Route::post('/admin_sponsorship_payment_delete', [ApiController::class, 'admin_sponsorship_payment_delete']);

    // Dashboard overview & Tasks
    Route::post('/admin_dashboard_overview', [ApiController::class, 'admin_dashboard_overview']);
    Route::post('/admin_task_list', [ApiController::class, 'admin_task_list']);
    Route::post('/admin_task_store', [ApiController::class, 'admin_task_store']);
    Route::post('/admin_task_update', [ApiController::class, 'admin_task_update']);
    Route::post('/admin_task_complete', [ApiController::class, 'admin_task_complete']);
    Route::post('/admin_task_delete', [ApiController::class, 'admin_task_delete']);

    // Sponsor Portal - sponsor-facing
    Route::post('/sponsor_my_children', [ApiController::class, 'sponsor_my_children']);
    Route::post('/sponsor_child_reports', [ApiController::class, 'sponsor_child_reports']);
    Route::post('/sponsor_message_thread', [ApiController::class, 'sponsor_message_thread']);
    Route::post('/sponsor_message_send', [ApiController::class, 'sponsor_message_send']);

    // Sponsor Portal - child-facing
    Route::post('/orphan_sponsor_message_thread', [ApiController::class, 'orphan_sponsor_message_thread']);
    Route::post('/orphan_sponsor_message_send', [ApiController::class, 'orphan_sponsor_message_send']);

    // Admission - admin-facing
    Route::post('/admin_admission_single', [ApiController::class, 'admin_admission_single']);
    Route::post('/admin_teacher_admission_single', [ApiController::class, 'admin_teacher_admission_single']);
    Route::post('/admin_admission_bulk', [ApiController::class, 'admin_admission_bulk']);
    Route::post('/admin_admission_excel', [ApiController::class, 'admin_admission_excel']);
    Route::post('/admin_admission_word', [ApiController::class, 'admin_admission_word']);
    Route::post('/admin_set_school_code', [ApiController::class, 'admin_set_school_code']);
 // Student Identification Configuration (master spec §4.5)
 Route::post('/admin_student_number_format_show', [ApiController::class, 'adminStudentNumberFormatShow']);
 Route::post('/admin_student_number_format_save', [ApiController::class, 'adminStudentNumberFormatSave']);
 Route::post('/admin_student_number_format_preview', [ApiController::class, 'adminStudentNumberFormatPreview']);
 Route::post('/admin_student_number_sequence_reset', [ApiController::class, 'adminStudentNumberSequenceReset']);

    // Admin - student ID configuration (prefix/suffix/digit-length builder + live
    // preview). Implementation already existed in Traits\StudentIdConfigApi but
    // was never registered here, leaving the frontend's StudentIdConfigScreen
    // calling three dead endpoints.
    Route::post('/admin_student_id_config', [ApiController::class, 'admin_student_id_config']);
    Route::post('/admin_student_id_config_save', [ApiController::class, 'admin_student_id_config_save']);
    Route::post('/admin_student_id_preview', [ApiController::class, 'admin_student_id_preview']);

    // Student - attendance report/summary and progress summary. Implementations
    // already existed in Traits\StudentProgressApi and Traits\StudentAttendanceApi
    // but were never registered here, leaving StudentAttendanceScreen and
    // StudentProgressScreen calling dead endpoints.
    Route::post('/student_attendance_report', [ApiController::class, 'student_attendance_report']);
    Route::post('/student_attendance_summary', [ApiController::class, 'student_attendance_summary']);
    Route::post('/student_progress_summary', [ApiController::class, 'student_progress_summary']);

    // Reference data
    Route::post('/admin_class_list', [ApiController::class, 'admin_class_list']);
    Route::post('/admin_section_list', [ApiController::class, 'admin_section_list']);

    // Admin - class teacher assignment
    Route::post('/admin_class_teacher_list', [ApiController::class, 'admin_class_teacher_list']);
    Route::post('/admin_class_teacher_assign', [ApiController::class, 'admin_class_teacher_assign']);

    // Admin - subjects, teacher & schedule per class
    Route::post('/admin_class_subjects_list', [ApiController::class, 'admin_class_subjects_list']);
    Route::post('/admin_subject_create', [ApiController::class, 'admin_subject_create']);
    Route::post('/admin_class_subject_assign', [ApiController::class, 'admin_class_subject_assign']);
    Route::post('/admin_class_subject_remove', [ApiController::class, 'admin_class_subject_remove']);

    // Admin - Departments
    Route::post('/admin_departments_list', [ApiController::class, 'admin_departments_list']);
    Route::post('/admin_departments_create', [ApiController::class, 'admin_departments_create']);
    Route::post('/admin_departments_update', [ApiController::class, 'admin_departments_update']);
    Route::post('/admin_departments_delete', [ApiController::class, 'admin_departments_delete']);

    // Admin - Curricula
    Route::post('/admin_curricula_list', [ApiController::class, 'admin_curricula_list']);
    Route::post('/admin_curricula_create', [ApiController::class, 'admin_curricula_create']);
    Route::post('/admin_curricula_update', [ApiController::class, 'admin_curricula_update']);
    Route::post('/admin_curricula_delete', [ApiController::class, 'admin_curricula_delete']);

    // Admin - Curriculum versioning (§4.6). Prerequisites/co-requisites are
    // NOT duplicated here - that's already a subject-level feature, see
    // admin_subjects_catalog_create/update's prerequisite_subject_ids /
    // corequisite_subject_ids in AcademicCatalogController.
    Route::post('/admin_curriculum_version_list', [CurriculumVersionController::class, 'versionList']);
    Route::post('/admin_curriculum_version_save', [CurriculumVersionController::class, 'versionSave']);
    Route::post('/admin_curriculum_version_delete', [CurriculumVersionController::class, 'versionDelete']);
    Route::post('/admin_curriculum_competency_list', [CurriculumVersionController::class, 'competencyList']);
    Route::post('/admin_curriculum_competency_save', [CurriculumVersionController::class, 'competencySave']);
    Route::post('/admin_curriculum_competency_delete', [CurriculumVersionController::class, 'competencyDelete']);

    // Admin - Sections (full CRUD; admin_section_list above stays untouched)
    Route::post('/admin_sections_list', [ApiController::class, 'admin_sections_list']);
    Route::post('/admin_sections_create', [ApiController::class, 'admin_sections_create']);
    Route::post('/admin_sections_update', [ApiController::class, 'admin_sections_update']);
    Route::post('/admin_sections_delete', [ApiController::class, 'admin_sections_delete']);

    // Teacher - my classes (sections I'm the class teacher of)
    Route::post('/teacher_my_classes', [ApiController::class, 'teacher_my_classes']);
    Route::post('/teacher_class_students', [ApiController::class, 'teacher_class_students']);

    // Teacher - attendance
    Route::post('/teacher_attendance_classes', [ApiController::class, 'teacher_attendance_classes']);
    Route::post('/teacher_attendance_roster', [ApiController::class, 'teacher_attendance_roster']);
    Route::post('/teacher_attendance_submit', [ApiController::class, 'teacher_attendance_submit']);
    Route::post('/teacher_attendance_update', [ApiController::class, 'teacher_attendance_update']);
    Route::post('/teacher_attendance_history', [ApiController::class, 'teacher_attendance_history']);

    // Admin - attendance analytics & export
    Route::post('/admin_attendance_dashboard', [ApiController::class, 'admin_attendance_dashboard']);
    Route::post('/admin_attendance_export', [ApiController::class, 'admin_attendance_export']);

    // Teacher - grade entry (gradebook)
    Route::post('/teacher_gradebook_classes', [ApiController::class, 'teacher_gradebook_classes']);
    Route::post('/teacher_gradebook_roster', [ApiController::class, 'teacher_gradebook_roster']);
    Route::post('/teacher_gradebook_submit', [ApiController::class, 'teacher_gradebook_submit']);

    // Admin - gradebook review (read-only counterpart to teacher entry)
    Route::post('/admin_gradebook_exam_categories', [ApiController::class, 'admin_gradebook_exam_categories']);
    Route::post('/admin_gradebook_review', [ApiController::class, 'admin_gradebook_review']);

    // Admin - exam category management (Assessment Components, spec §4.11:
    // weighted components shared by Gradebook and Assessments)
    Route::post('/admin_gradebook_exam_category_create', [ApiController::class, 'admin_gradebook_exam_category_create']);
    Route::post('/admin_gradebook_exam_category_update', [ApiController::class, 'admin_gradebook_exam_category_update']);
    Route::post('/admin_gradebook_exam_category_delete', [ApiController::class, 'admin_gradebook_exam_category_delete']);

    // Teacher - announcements (section/subject-scoped posts)
    Route::post('/teacher_announcement_targets', [ApiController::class, 'teacher_announcement_targets']);
    Route::post('/teacher_announcement_list', [ApiController::class, 'teacher_announcement_list']);
    Route::post('/teacher_announcement_store', [ApiController::class, 'teacher_announcement_store']);
    Route::post('/teacher_announcement_delete', [ApiController::class, 'teacher_announcement_delete']);

    // Student - announcements (read-only, scoped to current section)
    Route::post('/student_announcement_list', [ApiController::class, 'student_announcement_list']);

    // Admin - announcement review (read-only counterpart to teacher posts)
    Route::post('/admin_announcement_review', [ApiController::class, 'admin_announcement_review']);

    // Teacher - lesson plans (draft/submit/edit, subject+section scoped)
    Route::post('/teacher_lesson_plan_targets', [ApiController::class, 'teacher_lesson_plan_targets']);
    Route::post('/teacher_lesson_plan_list', [ApiController::class, 'teacher_lesson_plan_list']);
    Route::post('/teacher_lesson_plan_store', [ApiController::class, 'teacher_lesson_plan_store']);
    Route::post('/teacher_lesson_plan_update', [ApiController::class, 'teacher_lesson_plan_update']);
    Route::post('/teacher_lesson_plan_delete', [ApiController::class, 'teacher_lesson_plan_delete']);

    // Admin - lesson plan review + approve/reject (read + decision, counterpart to teacher writes)
    Route::post('/admin_lesson_plan_review', [ApiController::class, 'admin_lesson_plan_review']);
    Route::post('/admin_lesson_plan_decide', [ApiController::class, 'admin_lesson_plan_decide']);

    // Teacher - assessments & assignments (definitions: draft/publish/edit, subject+section scoped)
    Route::post('/teacher_assessment_targets', [ApiController::class, 'teacher_assessment_targets']);
    Route::post('/teacher_assessment_list', [ApiController::class, 'teacher_assessment_list']);
    Route::post('/teacher_assessment_store', [ApiController::class, 'teacher_assessment_store']);
    Route::post('/teacher_assessment_update', [ApiController::class, 'teacher_assessment_update']);
    Route::post('/teacher_assessment_delete', [ApiController::class, 'teacher_assessment_delete']);

    // Teacher - assessment grading (submissions roster + grade/request-resubmission)
    Route::post('/teacher_assessment_submissions', [ApiController::class, 'teacher_assessment_submissions']);
    Route::post('/teacher_assessment_grade', [ApiController::class, 'teacher_assessment_grade']);

    // Teacher/Student/Admin - weighted grade calculation (§4.11 -> §5 wiring)
    Route::post('/teacher_assessment_grades', [ApiController::class, 'teacher_assessment_grades']);
    Route::post('/student_assessment_grades', [ApiController::class, 'student_assessment_grades']);
    Route::post('/admin_assessment_grades', [ApiController::class, 'admin_assessment_grades']);

    // Student - assessments (view assigned work, submit/resubmit work)
    Route::post('/student_assessment_list', [ApiController::class, 'student_assessment_list']);
    Route::post('/student_assessment_submit', [ApiController::class, 'student_assessment_submit']);

    // Admin - assessment review (read-only counterpart to teacher writes)
    Route::post('/admin_assessment_review', [ApiController::class, 'admin_assessment_review']);
    Route::post('/admin_assessment_submissions', [ApiController::class, 'admin_assessment_submissions']);

    // Teacher - materials library (standalone resources, separate from lesson-plan
    // attachments and assessment submissions — spec §5/§6, roadmap #4)
    Route::post('/teacher_material_targets', [ApiController::class, 'teacher_material_targets']);
    Route::post('/teacher_material_list', [ApiController::class, 'teacher_material_list']);
    Route::post('/teacher_material_store', [ApiController::class, 'teacher_material_store']);
    Route::post('/teacher_material_delete', [ApiController::class, 'teacher_material_delete']);

    // Student - materials library (read-only, scoped to current section)
    Route::post('/student_material_list', [ApiController::class, 'student_material_list']);

    // Admin - materials review (read-only counterpart to teacher writes)
    Route::post('/admin_material_review', [ApiController::class, 'admin_material_review']);

    // Teacher - monthly reports
    Route::post('/teacher_report_status', [ApiController::class, 'teacher_report_status']);
    Route::post('/teacher_report_submit', [ApiController::class, 'teacher_report_submit']);

    // Admin - view teacher monthly reports
    Route::post('/admin_teacher_spreadsheet_import', [ApiController::class, 'admin_teacher_spreadsheet_import']);
    Route::post('/admin_teacher_report_list', [ApiController::class, 'admin_teacher_report_list']);
    Route::post('/admin_teacher_report_overview', [ApiController::class, 'admin_teacher_report_overview']);
    Route::post('/admin_teacher_profile', [ApiController::class, 'admin_teacher_profile']);
    Route::post('/admin_teacher_profile_update', [ApiController::class, 'admin_teacher_profile_update']);
    Route::post('/admin_user_documents_list', [ApiController::class, 'admin_user_documents_list']);
    Route::post('/admin_user_document_upload', [ApiController::class, 'admin_user_document_upload']);
    Route::post('/admin_user_document_delete', [ApiController::class, 'admin_user_document_delete']);

    // Chat / Messaging - same-school, any user to any user
    Route::post('/message_thread_list', [ApiController::class, 'message_thread_list']);
    Route::post('/message_thread_start', [ApiController::class, 'message_thread_start']);
    Route::post('/message_chat_list', [ApiController::class, 'message_chat_list']);
    Route::post('/message_chat_send', [ApiController::class, 'message_chat_send']);
    Route::post('/message_user_search', [ApiController::class, 'message_user_search']);

    // Posting system - feed, hearts, comments, reposts
    Route::post('/post_feed', [PostController::class, 'feed']);
    Route::post('/post_create', [PostController::class, 'store']);
    Route::post('/post_delete', [PostController::class, 'destroy']);
    Route::post('/post_update', [PostController::class, 'update']);
    Route::post('/post_like_toggle', [PostController::class, 'toggleLike']);
    Route::post('/post_comment_list', [PostController::class, 'commentList']);
    Route::post('/post_comment_create', [PostController::class, 'commentCreate']);
    Route::post('/post_comment_delete', [PostController::class, 'commentDelete']);
    Route::post('/post_repost', [PostController::class, 'repost']);
    Route::post('/post_comment_like_toggle', [PostController::class, 'commentLikeToggle']);
    Route::post('/profile_feed', [PostController::class, 'profileFeed']);

    // Class Management - Full CRUD (expanded class card feature)
    // Note: admin_classes_* (plural) - distinct from the existing
    // admin_class_list / admin_class_teacher_list routes above, which are
    // left untouched and still power the admission screen dropdowns.
    Route::post('/admin_classes_create', [ApiController::class, 'admin_classes_create']);
    Route::post('/admin_classes_list', [ApiController::class, 'admin_classes_list']);
    Route::post('/admin_classes_detail', [ApiController::class, 'admin_classes_detail']);
    Route::post('/admin_classes_update', [ApiController::class, 'admin_classes_update']);
    Route::post('/admin_classes_delete', [ApiController::class, 'admin_classes_delete']);
    Route::post('/admin_classes_archive', [ApiController::class, 'admin_classes_archive']);
    Route::post('/admin_classes_restore', [ApiController::class, 'admin_classes_restore']);
    Route::post('/admin_classes_duplicate', [ApiController::class, 'admin_classes_duplicate']);
    Route::post('/admin_classes_export', [ApiController::class, 'admin_classes_export']);
    Route::post('/admin_classes_reference_data', [ApiController::class, 'admin_classes_reference_data']);
    Route::post('/admin_academic_dashboard_stats', [ApiController::class, 'admin_academic_dashboard_stats']);

    // Section enrollment (admin-facing roster management - distinct from
    // teacher_class_students, which requires the requester to be the section's
    // class teacher)
    Route::post('/admin_section_students', [ApiController::class, 'admin_section_students']);
    Route::post('/admin_section_eligible_students', [ApiController::class, 'admin_section_eligible_students']);
    Route::post('/admin_section_add_students', [ApiController::class, 'admin_section_add_students']);
    Route::post('/admin_section_remove_student', [ApiController::class, 'admin_section_remove_student']);
    Route::post('/admin_section_transfer_student', [ApiController::class, 'admin_section_transfer_student']);

    // Class Information - read-only, any authenticated same-school user
    Route::post('/user_classes_detail', [ApiController::class, 'user_classes_detail']);
    Route::post('/student_classes_mine', [ApiController::class, 'student_classes_mine']);
    Route::post('/teacher_classes_mine', [ApiController::class, 'teacher_classes_mine']);

    // Admin - Academic Setup Wizard (Phase 3: institution profile, academic year/terms)
    Route::post('/admin_school_setup_status', [AcademicSetupController::class, 'admin_school_setup_status']);
    Route::post('/admin_school_profile_update', [AcademicSetupController::class, 'admin_school_profile_update']);
    Route::post('/admin_school_setup_complete', [AcademicSetupController::class, 'admin_school_setup_complete']);
    Route::post('/admin_sessions_list', [AcademicSetupController::class, 'admin_sessions_list']);
    Route::post('/admin_sessions_create', [AcademicSetupController::class, 'admin_sessions_create']);
    Route::post('/admin_sessions_update', [AcademicSetupController::class, 'admin_sessions_update']);
    Route::post('/admin_sessions_set_current', [AcademicSetupController::class, 'admin_sessions_set_current']);
    Route::post('/admin_sessions_delete', [AcademicSetupController::class, 'admin_sessions_delete']);
    Route::post('/admin_academic_terms_list', [AcademicSetupController::class, 'admin_academic_terms_list']);
    Route::post('/admin_academic_terms_create', [AcademicSetupController::class, 'admin_academic_terms_create']);
    Route::post('/admin_academic_terms_update', [AcademicSetupController::class, 'admin_academic_terms_update']);
    Route::post('/admin_academic_terms_set_current', [AcademicSetupController::class, 'admin_academic_terms_set_current']);
    Route::post('/admin_academic_terms_delete', [AcademicSetupController::class, 'admin_academic_terms_delete']);

    // Subscription / academic-status gating (endpoints already exist in
    // ApiController.php - see §12 of the spec; these two routes were the
    // only missing piece, per the "Not yet wired" note there)
    Route::post('/admin_subscription_status', [ApiController::class, 'admin_subscription_status']);
    Route::post('/student_academic_status', [ApiController::class, 'student_academic_status']);

    // Admin - Academic Catalog (Phase 4: Programs, Subject catalog, Grading Systems, Grade Scales)
    Route::post('/admin_programs_list', [AcademicCatalogController::class, 'admin_programs_list']);
    Route::post('/admin_programs_create', [AcademicCatalogController::class, 'admin_programs_create']);
    Route::post('/admin_programs_update', [AcademicCatalogController::class, 'admin_programs_update']);
    Route::post('/admin_programs_delete', [AcademicCatalogController::class, 'admin_programs_delete']);
    Route::post('/admin_subjects_catalog_list', [AcademicCatalogController::class, 'admin_subjects_catalog_list']);
    Route::post('/admin_subjects_catalog_create', [AcademicCatalogController::class, 'admin_subjects_catalog_create']);
    Route::post('/admin_subjects_catalog_update', [AcademicCatalogController::class, 'admin_subjects_catalog_update']);
    Route::post('/admin_subjects_catalog_delete', [AcademicCatalogController::class, 'admin_subjects_catalog_delete']);
    Route::post('/admin_grading_systems_list', [AcademicCatalogController::class, 'admin_grading_systems_list']);
    Route::post('/admin_grading_systems_create', [AcademicCatalogController::class, 'admin_grading_systems_create']);
    Route::post('/admin_grading_systems_update', [AcademicCatalogController::class, 'admin_grading_systems_update']);
    Route::post('/admin_grading_systems_delete', [AcademicCatalogController::class, 'admin_grading_systems_delete']);
    Route::post('/admin_grade_scales_list', [AcademicCatalogController::class, 'admin_grade_scales_list']);
    Route::post('/admin_grade_scales_create', [AcademicCatalogController::class, 'admin_grade_scales_create']);
    Route::post('/admin_grade_scales_new_version', [AcademicCatalogController::class, 'admin_grade_scales_new_version']);
    Route::post('/admin_grade_scales_update', [AcademicCatalogController::class, 'admin_grade_scales_update']);
    Route::post('/admin_grade_scales_delete', [AcademicCatalogController::class, 'admin_grade_scales_delete']);

    // Student - resolves marks against admin-configured grading systems
    // (spec 4.9/4.10), read-only. See Status 12's GPA blocker note.
    Route::post('/student_subject_grade_bands', [AcademicCatalogController::class, 'student_subject_grade_bands']);
    Route::post('/student_gpa_summary', [AcademicCatalogController::class, 'student_gpa_summary']);

    // Admin - Enrollment Workflow Management (spec 4.16) - stage config
    Route::post('/admin_enrollment_stages_list', [EnrollmentWorkflowController::class, 'admin_enrollment_stages_list']);
    Route::post('/admin_enrollment_stages_create', [EnrollmentWorkflowController::class, 'admin_enrollment_stages_create']);
    Route::post('/admin_enrollment_stages_update', [EnrollmentWorkflowController::class, 'admin_enrollment_stages_update']);
    Route::post('/admin_enrollment_stages_reorder', [EnrollmentWorkflowController::class, 'admin_enrollment_stages_reorder']);
    Route::post('/admin_enrollment_stages_delete', [EnrollmentWorkflowController::class, 'admin_enrollment_stages_delete']);

    // Admin - Enrollment Workflow Management (spec 4.16) - student progress & audit trail
    Route::post('/admin_enrollment_workflow_list', [EnrollmentWorkflowController::class, 'admin_enrollment_workflow_list']);
    Route::post('/admin_enrollment_workflow_start', [EnrollmentWorkflowController::class, 'admin_enrollment_workflow_start']);
    Route::post('/admin_enrollment_workflow_advance', [EnrollmentWorkflowController::class, 'admin_enrollment_workflow_advance']);
    Route::post('/admin_enrollment_workflow_withdraw', [EnrollmentWorkflowController::class, 'admin_enrollment_workflow_withdraw']);
    Route::post('/admin_enrollment_workflow_history', [EnrollmentWorkflowController::class, 'admin_enrollment_workflow_history']);

    // Student-facing (fixes spec §12 "Blocker A" - was admin-only before this).
    Route::post('/student_enrollment_workflow_status', [EnrollmentWorkflowController::class, 'student_enrollment_workflow_status']);

    // Admin - Academic Structure Builder (spec §4.1) - Campuses/branches.
    // First §4.1 entity built; Faculties, grade levels, and buildings/rooms
    // are the natural next additions to AcademicStructureController.
    Route::post('/admin_campuses_list', [AcademicStructureController::class, 'admin_campuses_list']);
    Route::post('/admin_campuses_create', [AcademicStructureController::class, 'admin_campuses_create']);
    Route::post('/admin_campuses_update', [AcademicStructureController::class, 'admin_campuses_update']);
    Route::post('/admin_campuses_delete', [AcademicStructureController::class, 'admin_campuses_delete']);

    // Admin - Academic Structure Builder (spec §4.1) - Grade levels/year levels.
    Route::post('/admin_grade_levels_list', [AcademicStructureController::class, 'admin_grade_levels_list']);
    Route::post('/admin_grade_levels_create', [AcademicStructureController::class, 'admin_grade_levels_create']);
    Route::post('/admin_grade_levels_update', [AcademicStructureController::class, 'admin_grade_levels_update']);
    Route::post('/admin_grade_levels_delete', [AcademicStructureController::class, 'admin_grade_levels_delete']);
    Route::post('/admin_grade_levels_reorder', [AcademicStructureController::class, 'admin_grade_levels_reorder']);

    // Student Portal - official identity card, resolved from auth user only.
    // Six-phase completion release: catalog, enrollment, documents, permissions, integrations, QA.
    Route::post('/admin_completion_overview', [AcademicCompletionController::class, 'records']);
    Route::post('/admin_curriculum_requirements', [AcademicCompletionEngineController::class, 'requirements']);
    Route::post('/admin_enrollment_subject_loading', [SubjectLoadingController::class, 'adminSubjectLoadingList']);
    Route::post('/admin_academic_documents', [AcademicDocumentController::class, 'issued']);
    Route::post('/admin_permission_audit', [AcademicAuthorizationController::class, 'audit']);

    // §4.20 Real permissions CRUD
    Route::post('/admin_permission_catalog', [PermissionController::class, 'catalog']);
    Route::post('/admin_permission_list', [PermissionController::class, 'list']);
    Route::post('/admin_permission_save', [PermissionController::class, 'save']);
    Route::post('/admin_permission_delete', [PermissionController::class, 'delete']);
    Route::post('/admin_capability_flag_list', [PermissionController::class, 'capabilityList']);
    Route::post('/admin_capability_flag_save', [PermissionController::class, 'capabilitySave']);
    Route::post('/admin_integrations_status', [AcademicIntegrationController::class, 'list']);
    Route::post('/admin_release_health', [AcademicCompletionController::class, 'releaseHealth']);

    Route::post('/student_identity', [StudentIdentityController::class, 'show']);

    // ------------------------------------------------------------------
    // P15 wiring: connects controllers/services built in earlier phases
    // to the endpoint names the RN app's service layer already calls.
    // Nothing below changes controller logic - route names only.
    // ------------------------------------------------------------------

    // Grade computation and release (P04)
    Route::post('/admin_grade_versions', [AcademicGradeController::class, 'versions']);
    Route::post('/admin_grade_calculate', [AcademicGradeController::class, 'calculate']);
    Route::post('/admin_grade_save', [AcademicGradeController::class, 'save']);
    Route::post('/admin_grade_submit', [AcademicGradeController::class, 'submit']);
    Route::post('/admin_grade_approve', [AcademicGradeController::class, 'approve']);
    Route::post('/admin_grade_list', [AcademicGradeController::class, 'list']);
    Route::post('/admin_grade_audit', [AcademicGradeController::class, 'audit']);

    // Scheduling / timetable conflict engine (P02)
    Route::post('/admin_schedule_list', [AcademicScheduleController::class, 'list']);
    Route::post('/admin_schedule_check_conflicts', [AcademicScheduleController::class, 'check']);
    Route::post('/admin_schedule_store', [AcademicScheduleController::class, 'store']);
    Route::post('/admin_schedule_update', [AcademicScheduleController::class, 'update']);
    Route::post('/admin_schedule_status', [AcademicScheduleController::class, 'status']);
    Route::post('/admin_schedule_audit', [AcademicScheduleController::class, 'audit']);
    Route::post('/admin_schedule_delete', [AcademicScheduleController::class, 'delete']);
    Route::post('/my_schedules', [AcademicScheduleController::class, 'mine']);

    // Promotion / retention policy engine (P05)
    Route::post('/admin_academic_policy_list', [AcademicPolicyController::class, 'policies']);
    Route::post('/admin_academic_policy_save', [AcademicPolicyController::class, 'policySave']);
    Route::post('/admin_academic_policy_evaluate', [AcademicPolicyController::class, 'evaluate']);
    Route::post('/admin_academic_policy_decision_save', [AcademicPolicyController::class, 'save']);
    Route::post('/admin_academic_policy_decision_approve', [AcademicPolicyController::class, 'approve']);
    Route::post('/admin_academic_policy_decision_list', [AcademicPolicyController::class, 'list']);
    Route::post('/admin_academic_policy_audit', [AcademicPolicyController::class, 'audit']);

    // Graduation / completion evaluation engine (P06)
    // No existing frontend caller was found for this controller; endpoint
    // names below follow the app's existing admin_<feature>_<action> style.
    Route::post('/admin_graduation_requirements', [AcademicCompletionEngineController::class, 'requirements']);
    Route::post('/admin_graduation_requirement_save', [AcademicCompletionEngineController::class, 'requirementSave']);
    Route::post('/admin_graduation_evaluate', [AcademicCompletionEngineController::class, 'evaluate']);
    Route::post('/admin_graduation_save', [AcademicCompletionEngineController::class, 'save']);
    Route::post('/admin_graduation_approve', [AcademicCompletionEngineController::class, 'approve']);
    Route::post('/admin_graduation_list', [AcademicCompletionEngineController::class, 'list']);
    Route::post('/admin_graduation_audit', [AcademicCompletionEngineController::class, 'audit']);

    // Analytics (P10)
    Route::post('/admin_academic_analytics_dashboard', [AcademicAnalyticsController::class, 'dashboard']);
    Route::post('/admin_academic_analytics_student', [AcademicAnalyticsController::class, 'student']);
    Route::post('/admin_academic_analytics_attendance_trend', [AcademicAnalyticsController::class, 'attendanceTrend']);

    // Authorization / school-scoping (P03)
    Route::post('/academic_my_scope', [AcademicAuthorizationController::class, 'myScope']);
    Route::post('/academic_authorize_student', [AcademicAuthorizationController::class, 'authorizeStudent']);
    Route::post('/admin_academic_access_audit', [AcademicAuthorizationController::class, 'audit']);

    // Academic calendar (P09)
    Route::post('/admin_calendar_events', [AcademicCalendarController::class, 'list']);
    Route::post('/admin_calendar_event_store', [AcademicCalendarController::class, 'store']);
    Route::post('/admin_calendar_event_update', [AcademicCalendarController::class, 'update']);
    Route::post('/admin_calendar_event_delete', [AcademicCalendarController::class, 'delete']);
    Route::post('/calendar_events_mine', [AcademicCalendarController::class, 'mine']);

    // Notifications and messaging (P12)
    Route::post('/academic_notifications', [AcademicCommunicationController::class, 'notifications']);
    Route::post('/academic_notification_read', [AcademicCommunicationController::class, 'read']);
    Route::post('/academic_message_threads', [AcademicCommunicationController::class, 'threads']);
    Route::post('/academic_message_thread_start', [AcademicCommunicationController::class, 'start']);
    Route::post('/academic_message_send', [AcademicCommunicationController::class, 'send']);
    Route::post('/academic_messages', [AcademicCommunicationController::class, 'messages']);

    // Documents and certificates (P07)
    Route::post('/admin_document_templates', [AcademicDocumentController::class, 'templates']);
    Route::post('/admin_document_template_save', [AcademicDocumentController::class, 'saveTemplate']);
    Route::post('/admin_document_template_approve', [AcademicDocumentController::class, 'approveTemplate']);
    Route::post('/admin_document_preview', [AcademicDocumentController::class, 'preview']);
    Route::post('/admin_document_issue', [AcademicDocumentController::class, 'issue']);
    Route::post('/admin_document_issued', [AcademicDocumentController::class, 'issued']);
    Route::post('/admin_document_audit', [AcademicDocumentController::class, 'audit']);

    // Facilities: buildings and rooms (P13-adjacent structure)
    Route::post('/admin_facilities_buildings', [AcademicFacilitiesController::class, 'buildings']);
    Route::post('/admin_facilities_building_store', [AcademicFacilitiesController::class, 'storeBuilding']);
    Route::post('/admin_facilities_building_update', [AcademicFacilitiesController::class, 'updateBuilding']);
    Route::post('/admin_facilities_building_delete', [AcademicFacilitiesController::class, 'deleteBuilding']);
    Route::post('/admin_facilities_rooms', [AcademicFacilitiesController::class, 'rooms']);
    Route::post('/admin_facilities_room_store', [AcademicFacilitiesController::class, 'storeRoom']);
    Route::post('/admin_facilities_room_update', [AcademicFacilitiesController::class, 'updateRoom']);
    Route::post('/admin_facilities_room_delete', [AcademicFacilitiesController::class, 'deleteRoom']);

    // Finance/library/device integrations (P13)
    Route::post('/admin_academic_integrations', [AcademicIntegrationController::class, 'list']);
    Route::post('/admin_academic_integration_save', [AcademicIntegrationController::class, 'save']);
    Route::post('/admin_academic_integration_sync', [AcademicIntegrationController::class, 'sync']);
    Route::post('/admin_academic_sync_runs', [AcademicIntegrationController::class, 'runs']);

    // Localization and translations (P09)
    Route::post('/academic_locale_bundle', [AcademicLocaleController::class, 'bundle']);
    Route::post('/admin_locale_preferences', [AcademicLocaleController::class, 'preferences']);
    Route::post('/admin_locale_list_save', [AcademicLocaleController::class, 'locales']);
    Route::post('/admin_translations_save', [AcademicLocaleController::class, 'translations']);

    // Portal completion (P11)
    Route::post('/student_portal_home', [AcademicPortalController::class, 'studentHome']);
    Route::post('/portal_document_show', [AcademicPortalController::class, 'document']);
    Route::post('/admin_portal_document_issue', [AcademicPortalController::class, 'issue']);
    Route::post('/portal_action_submit', [AcademicPortalController::class, 'submitAction']);
    Route::post('/admin_portal_actions', [AcademicPortalController::class, 'actions']);

    // Student lifecycle management (P08)
    Route::post('/admin_student_lifecycle_change', [AcademicStudentLifecycleController::class, 'change']);
    Route::post('/admin_student_lifecycle_history', [AcademicStudentLifecycleController::class, 'history']);
    Route::post('/admin_student_import_preview', [AcademicStudentLifecycleController::class, 'importPreview']);
    Route::post('/admin_student_import_commit', [AcademicStudentLifecycleController::class, 'importCommit']);
    Route::post('/admin_student_import_batches', [AcademicStudentLifecycleController::class, 'batches']);

    // Subject Loading Engine (P01)
    Route::post('/admin_subject_loading_context', [SubjectLoadingController::class, 'adminSubjectLoadingContext']);
    Route::post('/admin_subject_loading_eligibility', [SubjectLoadingController::class, 'adminSubjectLoadingEligibility']);
    Route::post('/admin_subject_loading_store', [SubjectLoadingController::class, 'adminSubjectLoadingStore']);
    Route::post('/admin_subject_loading_submit', [SubjectLoadingController::class, 'adminSubjectLoadingSubmit']);
    Route::post('/admin_subject_loading_approve', [SubjectLoadingController::class, 'adminSubjectLoadingApprove']);
    Route::post('/admin_subject_loading_reject', [SubjectLoadingController::class, 'adminSubjectLoadingReject']);
    Route::post('/admin_subject_loading_cancel', [SubjectLoadingController::class, 'adminSubjectLoadingCancel']);
    Route::post('/admin_subject_loading_drop_item', [SubjectLoadingController::class, 'adminSubjectLoadingDropItem']);
    Route::post('/admin_subject_loading_list', [SubjectLoadingController::class, 'adminSubjectLoadingList']);
    Route::post('/admin_subject_loading_detail', [SubjectLoadingController::class, 'adminSubjectLoadingDetail']);
    Route::post('/admin_subject_loading_audit', [SubjectLoadingController::class, 'adminSubjectLoadingAudit']);
    Route::post('/admin_load_policy_list', [SubjectLoadingController::class, 'adminLoadPolicyList']);
    Route::post('/admin_load_policy_save', [SubjectLoadingController::class, 'adminLoadPolicySave']);
    Route::post('/admin_load_policy_delete', [SubjectLoadingController::class, 'adminLoadPolicyDelete']);

    // §4.13 Attendance configuration builder
    Route::post('/admin_attendance_status_list', [AttendanceConfigController::class, 'statusList']);
    Route::post('/admin_attendance_status_save', [AttendanceConfigController::class, 'statusSave']);
    Route::post('/admin_attendance_status_delete', [AttendanceConfigController::class, 'statusDelete']);
    Route::post('/admin_attendance_method_list', [AttendanceConfigController::class, 'methodList']);
    Route::post('/admin_attendance_method_save', [AttendanceConfigController::class, 'methodSave']);
    Route::post('/admin_attendance_method_delete', [AttendanceConfigController::class, 'methodDelete']);
    Route::post('/student_subject_load', [SubjectLoadingController::class, 'studentSubjectLoad']);
    Route::post('/teacher_subject_load_advisees', [SubjectLoadingController::class, 'teacherSubjectLoadAdvisees']);
});

Route::prefix('academic/setup')->group(function(){
 Route::get('/status',[AcademicSetupPhase6Controller::class,'status']);
 Route::post('/profile',[AcademicSetupPhase6Controller::class,'profile']);
 Route::post('/years',[AcademicSetupPhase6Controller::class,'year']);
 Route::post('/terms',[AcademicSetupPhase6Controller::class,'term']);
 Route::post('/complete',[AcademicSetupPhase6Controller::class,'complete']);
});
