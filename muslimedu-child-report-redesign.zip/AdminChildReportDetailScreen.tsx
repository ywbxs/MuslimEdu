import React, { useCallback, useEffect, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Image,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useAuth } from '../../context/AuthContext';
import { MonthlyReport } from '../../services/orphanService';
import {
  fetchChildReports,
  createChildReport,
  deleteChildReport,
} from '../../services/adminOrphanReportService';
import { Skeleton } from '../../components/Skeleton';
import RatingGauge from '../../components/RatingGauge';
import PhotoLightbox from '../../components/PhotoLightbox';

import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { SHADOW } from '../../theme/spatial';
const EMERALD = '#0F9D58';
const EMERALD_SOFT = '#EAF7EF';
const GOLD = '#B8912F';
const INK = '#14171A';
const SUBTLE = '#7A8078';
const DANGER = '#E0637A';
const CANVAS = '#F3F5F2';

function RatingSelector({ label, value, onChange }: { label: string; value: number | null; onChange: (v: number) => void }) {
  return (
    <View style={{ marginBottom: 16 }}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <View style={styles.ratingRow}>
        {[1, 2, 3, 4, 5].map((n) => (
          <TouchableOpacity
            key={n}
            style={[styles.ratingPill, value === n && styles.ratingPillSelected]}
            onPress={() => onChange(n)}
          >
            <Text style={[styles.ratingPillText, value === n && styles.ratingPillTextSelected]}>{n}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

export default function AdminChildReportDetailScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const route = useRoute();
  const { studentId, studentName } = (route.params as { studentId: number; studentName: string }) ?? {};
  const { token } = useAuth();

  const [reports, setReports] = useState<MonthlyReport[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);

  const [note, setNote] = useState('');
  const [academicRating, setAcademicRating] = useState<number | null>(null);
  const [wellbeingRating, setWellbeingRating] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Full-screen photo viewer state - which report's photos are open, and
  // at which index, so PhotoLightbox can be a single shared instance for
  // the whole screen instead of one per report card.
  const [lightboxPhotos, setLightboxPhotos] = useState<string[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [lightboxVisible, setLightboxVisible] = useState(false);

  const load = useCallback(async () => {
    if (!token) return;
    setError(null);
    try {
      const data = await fetchChildReports(token, studentId);
      setReports(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load reports.');
    }
  }, [token, studentId]);

  useEffect(() => {
    setIsLoading(true);
    load().finally(() => setIsLoading(false));
  }, [load]);

  const handleCreate = async () => {
    if (!token || !academicRating || !wellbeingRating) {
      Alert.alert('Almost done', 'Please select both ratings.');
      return;
    }
    setIsSubmitting(true);
    try {
      await createChildReport(
        token,
        studentId,
        { note, academic_rating: academicRating, wellbeing_rating: wellbeingRating },
      );
      Alert.alert('Report added', `A report was added for ${studentName}.`);
      setShowForm(false);
      setNote('');
      setAcademicRating(null);
      setWellbeingRating(null);
      await load();
    } catch (err) {
      Alert.alert('Something went wrong', err instanceof Error ? err.message : 'Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = (reportId: number) => {
    Alert.alert('Delete report', 'This cannot be undone. Continue?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          if (!token) return;
          try {
            await deleteChildReport(token, reportId);
            await load();
          } catch (err) {
            Alert.alert('Could not delete', err instanceof Error ? err.message : 'Please try again.');
          }
        },
      },
    ]);
  };

  const openLightbox = (photos: string[], index: number) => {
    setLightboxPhotos(photos);
    setLightboxIndex(index);
    setLightboxVisible(true);
  };

  return (
    <View style={styles.flex}>
      <View style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} hitSlop={10}>
          <Text style={styles.backText}>Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>{studentName}</Text>
        <View style={{ width: 40 }} />
      </View>

      {isLoading ? (
        <View style={styles.scrollContent}>
          <Skeleton width="100%" height={52} borderRadius={16} style={{ marginBottom: 20 }} />
          <Skeleton width={80} height={12} style={{ marginBottom: 10 }} />
          {[0, 1].map((i) => (
            <View key={i} style={styles.reportCard}>
              <Skeleton width={100} height={13} style={{ marginBottom: 8 }} />
              <Skeleton width="90%" height={11} style={{ marginBottom: 6 }} />
              <Skeleton width="60%" height={11} />
            </View>
          ))}
        </View>
      ) : error ? (
        <View style={styles.center}>
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity onPress={load} style={styles.retryButton}>
            <Text style={styles.retryText}>Try again</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.scrollContent}>
          {!showForm && (
            <TouchableOpacity style={styles.addButton} onPress={() => setShowForm(true)}>
              <Text style={styles.addButtonText}>+ Add Report on Their Behalf</Text>
            </TouchableOpacity>
          )}

          {showForm && (
            <View style={styles.formCard}>
              <Text style={styles.formTitle}>New Report</Text>
              <TextInput
                style={styles.noteInput}
                placeholder="Write a short note..."
                placeholderTextColor={SUBTLE}
                multiline
                value={note}
                onChangeText={setNote}
              />
              <RatingSelector label="Academic Rating" value={academicRating} onChange={setAcademicRating} />
              <RatingSelector label="Wellbeing Rating" value={wellbeingRating} onChange={setWellbeingRating} />

              <View style={styles.formButtonRow}>
                <TouchableOpacity style={styles.cancelButton} onPress={() => setShowForm(false)}>
                  <Text style={styles.cancelButtonText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.submitButton, isSubmitting && { opacity: 0.6 }]}
                  onPress={handleCreate}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <ActivityIndicator color="#FFFFFF" />
                  ) : (
                    <Text style={styles.submitButtonText}>Save Report</Text>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          )}

          <Text style={styles.sectionLabel}>History</Text>
          {reports.length === 0 ? (
            <Text style={styles.emptyText}>No reports submitted yet.</Text>
          ) : (
            reports.map((report) => (
              <View key={report.id} style={styles.reportCard}>
                <View style={styles.reportCardHeader}>
                  <Text style={styles.reportMonth}>{report.report_month}</Text>
                  <TouchableOpacity onPress={() => handleDelete(report.id)} hitSlop={8}>
                    <Text style={styles.deleteText}>Delete</Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.gaugeRow}>
                  <RatingGauge label="Academic" value={report.academic_rating} color={EMERALD} />
                  <RatingGauge label="Wellbeing" value={report.wellbeing_rating} color={GOLD} />
                </View>

                {report.note ? (
                  <View style={styles.noteBlock}>
                    <Text style={styles.reportNote}>{report.note}</Text>
                  </View>
                ) : null}

                <Text style={styles.reportSubmittedBy}>Submitted by {report.submitted_by ?? 'unknown'}</Text>

                {report.photos.length > 0 && (
                  <View style={styles.photoGrid}>
                    {report.photos.map((url, index) => (
                      <TouchableOpacity
                        key={url}
                        style={styles.photoTile}
                        activeOpacity={0.85}
                        onPress={() => openLightbox(report.photos, index)}
                      >
                        <Image source={{ uri: url }} style={styles.photoTileImage} />
                      </TouchableOpacity>
                    ))}
                  </View>
                )}
              </View>
            ))
          )}
        </ScrollView>
      )}

      <PhotoLightbox
        visible={lightboxVisible}
        photos={lightboxPhotos}
        initialIndex={lightboxIndex}
        onClose={() => setLightboxVisible(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: CANVAS },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  backText: { color: EMERALD, fontSize: 15, fontWeight: '600' },
  headerTitle: { fontSize: 17, fontWeight: '600', color: INK },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 24 },
  errorText: { color: '#D70015', textAlign: 'center', marginBottom: 12 },
  retryButton: { backgroundColor: '#F2F2F7', paddingVertical: 10, paddingHorizontal: 20, borderRadius: 10 },
  retryText: { color: INK, fontWeight: '600' },
  scrollContent: { padding: 16, paddingBottom: 40 },

  addButton: {
    backgroundColor: EMERALD_SOFT,
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
    marginBottom: 20,
  },
  addButtonText: { color: EMERALD, fontWeight: '700', fontSize: 14 },

  formCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    ...SHADOW.level1,
  },
  formTitle: { fontSize: 17, fontWeight: '700', color: INK, marginBottom: 14 },
  noteInput: {
    backgroundColor: CANVAS,
    borderRadius: 14,
    padding: 14,
    fontSize: 15,
    color: INK,
    minHeight: 80,
    textAlignVertical: 'top',
    marginBottom: 16,
  },
  fieldLabel: { fontSize: 13, fontWeight: '600', color: INK, marginBottom: 8 },
  ratingRow: { flexDirection: 'row', justifyContent: 'space-between' },
  ratingPill: { width: 44, height: 44, borderRadius: 22, backgroundColor: CANVAS, alignItems: 'center', justifyContent: 'center' },
  ratingPillSelected: { backgroundColor: EMERALD },
  ratingPillText: { fontSize: 15, fontWeight: '600', color: INK },
  ratingPillTextSelected: { color: '#FFFFFF' },
  formButtonRow: { flexDirection: 'row', marginTop: 4 },
  cancelButton: { flex: 1, paddingVertical: 14, alignItems: 'center', marginRight: 10 },
  cancelButtonText: { color: SUBTLE, fontWeight: '600' },
  submitButton: { flex: 2, backgroundColor: EMERALD, borderRadius: 14, paddingVertical: 14, alignItems: 'center' },
  submitButtonText: { color: '#FFFFFF', fontWeight: '700' },

  sectionLabel: { fontSize: 13, fontWeight: '600', color: SUBTLE, textTransform: 'uppercase', marginBottom: 10 },
  emptyText: { color: SUBTLE, fontSize: 14 },
  reportCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 22,
    padding: 18,
    marginBottom: 14,
    ...SHADOW.level1,
  },
  reportCardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 },
  reportMonth: { fontWeight: '800', color: INK, fontSize: 15 },
  deleteText: { color: DANGER, fontSize: 13, fontWeight: '600' },

  gaugeRow: { flexDirection: 'row', gap: 10, marginBottom: 14 },

  noteBlock: {
    backgroundColor: CANVAS,
    borderLeftWidth: 3,
    borderLeftColor: GOLD,
    borderTopRightRadius: 12,
    borderBottomRightRadius: 12,
    paddingVertical: 11,
    paddingHorizontal: 13,
    marginBottom: 10,
  },
  reportNote: { color: '#3A3F3C', fontSize: 13.5, lineHeight: 19 },
  reportSubmittedBy: { fontSize: 11, color: SUBTLE, fontStyle: 'italic', marginBottom: 12 },

  photoGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  photoTile: {
    width: '48%',
    aspectRatio: 1,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: CANVAS,
  },
  photoTileImage: { width: '100%', height: '100%' },
});
