# Build next all phases

This archive is deliberately one bundle. It does not add api phase files.

```bash
cd workspaces/MuslimEdu-backend
git pull
unzip -o muslimedu-next-all-phases.zip -d /tmp/muslimedu-next-all-phases
cp routes/api.php routes/api.php.backup
cp /tmp/muslimedu-next-all-phases/muslimedu-next-all-phases/routes-api.source.php routes/api.php
cp /tmp/muslimedu-next-all-phases/muslimedu-next-all-phases/STATUS.md STATUS.md
cp /tmp/muslimedu-next-all-phases/muslimedu-next-all-phases/ROADMAP.md ROADMAP.md
php -l routes/api.php
php artisan route:clear
php artisan route:list --path=api
php artisan migrate:status
git add routes/api.php STATUS.md ROADMAP.md
git commit -m "Build next all phases with unified API roadmap"
git push
```

The source file is the complete API supplied in this request. Existing controllers and models are not duplicated.
