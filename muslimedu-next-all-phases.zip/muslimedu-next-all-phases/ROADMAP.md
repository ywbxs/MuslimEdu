# MuslimEdu next phases roadmap

## M0: baseline
Fresh migrations, route cache reset, route smoke test, and a clean database boot.

## M1: contract audit
Extract frontend endpoint strings, compare them with routes/api.php, verify controller methods, and remove dead or duplicate calls.

## M2: backend completion
Implement only genuinely missing methods in existing controllers. Finish notifications, integrations, lifecycle/import, analytics, attendance configuration, and permissions.

## M3: academic verification
Regression-test setup, years, terms, structure, catalog, classes, sections, enrollment, grading, timetable, calendar, documents, and completion.

## M4: teacher portal
Verify examinations, reports, communication, profile, progress/risk, attendance, gradebook, announcements, lesson plans, assessments, and materials.

## M5: student portal
Verify submissions, documents, services, settings, attendance, progress, grades, materials, announcements, enrollment status, and portal actions.

## M6: hardening
School scoping, role checks, validation, upload protection, rate limits, idempotency, consistent errors, and removal of debug routes.

## M7: release
Security matrix, regression suite, fresh migration test, mobile smoke test, deployment, monitoring, and rollback.
